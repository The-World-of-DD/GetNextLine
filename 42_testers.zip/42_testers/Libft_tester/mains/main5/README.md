Objetivo: Crear un programa que pruebe las funciones de listas enlazadas como ft_lstnew, ft_lstadd_back, y ft_lstiter.

Instrucciones:

    Crea una lista enlazada simple con al menos tres nodos utilizando ft_lstnew y ft_lstadd_back.
    Recorre la lista y aplica una función a cada nodo.
    Asegúrate de liberar la memoria de la lista enlazada

Funciones a probar: ft_lstnew, ft_lstadd_back, ft_lstiter, ft_lstclear.