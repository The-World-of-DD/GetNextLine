Objetivo: Crear un programa que pruebe funciones básicas de manipulación de cadenas como ft_strlen, ft_strlcpy, ft_strlcat, ft_strjoin, y ft_strtrim.

Instrucciones:

    Calcula la longitud de una cadena
    Copia una cadena y luego concatena otra usando ft_strlcpy y ft_strlcat.
    Crea una nueva cadena uniendo dos cadenas
    Elimina los espacios en blanco al principio y al final de una cadena

Funciones a probar: printf, ft_strlen, ft_strlcpy, ft_strlcat, ft_strjoin, ft_strtrim.