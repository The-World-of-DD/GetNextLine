Objetivo: Crear un programa que pruebe las funciones de conversión ft_atoi y ft_itoa.

Instrucciones:

    Convierte una cadena de caracteres que contiene un número a un entero.
    Convierte un número entero en una cadena de caracteres utilizando.

Funciones a probar: ft_atoi, ft_itoa.