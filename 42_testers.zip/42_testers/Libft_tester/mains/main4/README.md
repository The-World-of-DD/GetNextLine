Objetivo: Crear un programa que pruebe las funciones de manipulación de memoria como ft_memset, ft_bzero, ft_memcpy, y ft_memmove.

Instrucciones:

    Rellena un bloque de memoria con un valor específico utilizando.
    Inicializa un bloque de memoria a cero
    Copia un bloque de memoria a otro bloque.
    Mueve un bloque de memoria a otro bloque, manejando correctamente las áreas que se solapan, utilizando ft_memmove.

Funciones a probar: ft_memset, ft_bzero, ft_memcpy, ft_memmove.