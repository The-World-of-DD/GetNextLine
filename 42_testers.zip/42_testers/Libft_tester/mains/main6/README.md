/*
Crea un programa en C que utilice las funciones ft_split, ft_strmapi, ft_toupper y ft_tolower de la librería libft para dividir una cadena de entrada en palabras, luego transformar las letras en cada palabra a mayúsculas y minúsculas alternadas. Finalmente, imprime las palabras resultantes.
*/

