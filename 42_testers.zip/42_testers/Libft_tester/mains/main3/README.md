Objetivo: Crear un programa que pruebe las funciones de entrada/salida ft_putstr_fd, ft_putendl_fd, ft_putchar_fd, y ft_putnbr_fd.

Instrucciones:

    Escribe una cadena de caracteres en un archivo utilizando ft_putstr_fd.
    Escribe una cadena seguida de una nueva línea en un archivo utilizando ft_putendl_fd.
    Escribe un solo carácter en un archivo utilizando ft_putchar_fd.
    Escribe un número entero en un archivo utilizando ft_putnbr_fd.

Funciones a probar: ft_putstr_fd, ft_putendl_fd, ft_putchar_fd, ft_putnbr_fd.